# Library to help navigate the local Weblogic environment

import xml.dom.minidom
import os
import socket
import re
import xml.sax.handler
import socket

def versiontuple(v):
	return tuple(map(int, (v.split("."))))

def check_server(address, port):
	# Create a TCP socket
	s = socket.socket()
	print "Attempting to connect to %s on port %s" % (address, port)
	try:
		s.connect((socket.gethostbyname(address), int(port)))
		print "Connected to %s on port %s" % (address, port)
		return True
	except socket.error, e:
		print "Connection to %s on port %s failed: %s" % (address, port, e)
		return False

def listens_locally(address):
	machIp = socket.gethostbyname(address)
	return (os.system("/sbin/ifconfig -a | grep %s > /dev/null" % (machIp)) == 0)

def xml2obj(src):
    """
    A simple function to converts XML data into native Python object.
    """
    
    non_id_char = re.compile('[^_0-9a-zA-Z]')
    def _name_mangle(name):
        return non_id_char.sub('_', name)
    
    class DataNode(object):
        def __init__(self):
            self._attrs = {}    # XML attributes and child elements
            self.data = None    # child text data
        def __len__(self):
            # treat single element as a list of 1
            return 1
        def __getitem__(self, key):
            if isinstance(key, basestring):
                return self._attrs.get(key,None)
            else:
                return [self][key]
        def __contains__(self, name):
            return self._attrs.has_key(name)
        def __nonzero__(self):
            return bool(self._attrs or self.data)
        def __getattr__(self, name):
            if name.startswith('__'):
                # need to do this for Python special methods???
                raise AttributeError(name)
            return self._attrs.get(name,None)
        def _add_xml_attr(self, name, value):
            if name in self._attrs:
                # multiple attribute of the same name are represented by a list
                children = self._attrs[name]
                if not isinstance(children, list):
                    children = [children]
                    self._attrs[name] = children
                children.append(value)
            else:
                self._attrs[name] = value
        def __str__(self):
            return self.data or ''
        def __repr__(self):
            items = sorted(self._attrs.items())
            if self.data:
                items.append(('data', self.data))
            return u'{%s}' % ', '.join([u'%s:%s' % (k,repr(v)) for k,v in items])
    
    class TreeBuilder(xml.sax.handler.ContentHandler):
        def __init__(self):
            self.stack = []
            self.root = DataNode()
            self.current = self.root
            self.text_parts = []
        def startElement(self, name, attrs):
            self.stack.append((self.current, self.text_parts))
            self.current = DataNode()
            self.text_parts = []
            # xml attributes --> python attributes
            for k, v in attrs.items():
                self.current._add_xml_attr(_name_mangle(k), v)
        def endElement(self, name):
            text = ''.join(self.text_parts).strip()
            if text:
                self.current.data = text
            if self.current._attrs:
                obj = self.current
            else:
                # a text only node is simply represented by the string
                obj = text or ''
            self.current, self.text_parts = self.stack.pop()
            self.current._add_xml_attr(_name_mangle(name), obj)
        def characters(self, content):
            self.text_parts.append(content)
    
    builder = TreeBuilder()
    xml.sax.parse(src, builder)
    return builder.root._attrs.values()[0]

def decrypt(domainHomeName, encryptedPwd):
	"""
	Only works when run in WLST
	"""
	import weblogic.security.internal.SerializedSystemIni
	import weblogic.security.internal.encryption.ClearOrEncryptedService
	domainHomeAbsolutePath = os.path.abspath(domainHomeName)
	encryptionService = weblogic.security.internal.SerializedSystemIni.getEncryptionService(domainHomeAbsolutePath)
	ces = weblogic.security.internal.encryption.ClearOrEncryptedService(encryptionService)
	clear = ces.decrypt(encryptedPwd)
	return clear

def encrypt(domainHomeName, encryptedPwd):
	"""
	Only works when run in WLST
	"""
	import weblogic.security.internal.SerializedSystemIni
	import weblogic.security.internal.encryption.ClearOrEncryptedService
	domainHomeAbsolutePath = os.path.abspath(domainHomeName)
	encryptionService = weblogic.security.internal.SerializedSystemIni.getEncryptionService(domainHomeAbsolutePath)
	ces = weblogic.security.internal.encryption.ClearOrEncryptedService(encryptionService)
	clear = ces.encrypt(encryptedPwd)
	return clear

def load_properties(filepath, sep='=', comment_char='#'):
    """
    Read the file passed as parameter as a properties file.
    """
    props = {}
    f = open(filepath, "rt")
    for line in f:
        l = line.strip()
        if l and not l.startswith(comment_char):
            key_value = l.split(sep)
            key = key_value[0].strip()
            value = sep.join(key_value[1:]).strip().strip('"') 
            props[key] = value.replace('\=','=')
    return props

class domainConfig:
	"""
	 Simply instantiate it and inspect the attributes
	
	 Public attributes:
	    homeList - Array containing a list of MW domains
	    homeList[i]['MW_HOME'] - Location of the application installation
	    homeList[i]['DOMAIN_HOME'] - Location of the domain home
	    inventoryPath - Location of the inventory.xml file
	"""
	def __init__(self, ignoreSubaruCfg=False):
		self.domainHome = os.environ['DOMAIN_HOME']
		self.configFile = os.path.join(self.domainHome, 'config', 'config.xml')
		if not(os.path.exists(self.configFile)):
			raise Exception('Could not find Weblogic config.xml')
		
		cfgObj = xml2obj(self.configFile)
		
		
		self.domainName = cfgObj.name
		self.domainVersion = cfgObj.domain_version
		
		if versiontuple(self.domainVersion) < versiontuple("12"):
			is12c = False
		else:
			is12c = True
		
		
		self.nmUser = cfgObj.security_configuration.node_manager_username
		self._nmPass = cfgObj.security_configuration.node_manager_password_encrypted
		
		for X in cfgObj.machine:
			if X.node_manager.listen_address != '' and listens_locally(X.node_manager.listen_address):
				self.machineName = X.name
				self.nmHost = X.node_manager.listen_address
				self.nmPort = X.node_manager.listen_port
				self.nmType = X.node_manager.nm_type
		
		if self.machineName == None:
			raise Exception('Could not idenitfy this machine in the domain configuration')
		
		if self.nmPort == None:
			self.nmPort = 5556
		if self.nmType == None:
			if is12c:
				self.nmType = 'SSL'
			else:
				self.nmType = 'Plain'
		
		self.servers = {}
		self.serversOnHost = []
		for X in cfgObj.server:
			
			self.servers[X.name] = { }
			
			if X.listen_port != None:
				self.servers[X.name]['listen_port'] = X.listen_port
			else:
				self.servers[X.name]['listen_port'] = 7001
			
			if X.machine != None:
				self.servers[X.name]['machine'] = X.machine
			
			if X.listen_address != None and X.listen_address != '':
				self.servers[X.name]['listen_address'] = X.listen_address
			elif (X.machine == self.machineName):
				self.servers[X.name]['listen_address'] = '127.0.0.1'
			
			if (X.machine == self.machineName) or (listens_locally(X.listen_address)):
				self.serversOnHost.append(X.name)
			
		
		self.adminServer = cfgObj.admin_server_name
		self.bootOrder = []
		
		self.subaruCfgFile = os.path.join(self.domainHome, 'config', 'subaru.xml')
		if os.path.exists(self.subaruCfgFile):
			subaruCfg = xml2obj(self.subaruCfgFile)
			self._adminUser = subaruCfg['adminUser']
			self._adminPass = subaruCfg['adminPass']
			if subaruCfg['bootOrder']:
				for X in subaruCfg.bootOrder:
					self.bootOrder.append((int(X['idx']),X['server']))
		elif not(ignoreSubaruCfg):
			raise Exception('Could not find subaru.xml config file--run setupScripts.sh')
		
		for X in self.servers:
			if not([item for item in self.bootOrder if item[1] == X]):
				if (X == self.adminServer):
					self.bootOrder.append((1,X))
				else:
					self.bootOrder.append((2,X))
			
		
	
	def nmPass(self):
		return decrypt(self.domainHome, self._nmPass)
	
	def adminUser(self):
		return decrypt(self.domainHome, self._adminUser)
	
	def adminPass(self):
		return decrypt(self.domainHome, self._adminPass)
	
	def debug(self):
		print("domainConfig.configFile = "+self.configFile)
		print("domainConfig.subaruCfgFile = "+self.subaruCfgFile)
		print("domainConfig.domainHome = "+self.domainHome)
		print("domainConfig.domainName = "+self.domainName)
		print("domainConfig.adminUser = "+('','*****')[len(self._adminUser)>0])
		print("domainConfig.adminPass = "+('','*****')[len(self._adminPass)>0])
		print("domainConfig.nmUser = "+self.nmUser)
		print("domainConfig.nmPass = "+('','*****')[len(self._nmPass)>0])
		print("domainConfig.machineName = "+self.machineName)
		print("domainConfig.nmHost = "+self.nmHost)
		print("domainConfig.nmPort = "+str(self.nmPort))
		print("domainConfig.nmType = "+self.nmType)
		print("domainConfig.adminServer = "+self.adminServer)
		for X in range(len(self.serversOnHost)):
			print ("domainConfig.serversOnHost[%d] = %s" % (X, self.serversOnHost[X]))
		for X in range(len(self.bootOrder)):
			print ("domainConfig.bootOrder[%d] = %s" % (X, self.bootOrder[X]))
		
	

class oraInventory:
	""" 
	Simply instantiate it and inspect the attributes
	
	 Public attributes:
	    homeList - Array containing a list of MW domains
	    homeList[i]['MW_HOME'] - Location of the application installation
	    homeList[i]['DOMAIN_HOME'] - Location of the domain home
	    inventoryPath - Location of the inventory.xml file
	"""
	def __init__(self):
		# Try to find oraInventory in home
		tryPaths = [
						os.path.expanduser('~/oraInventory/ContentsXML/inventory.xml'),
						'/u01/app/oraInventory/ContentsXML/inventory.xml',  # Oracle SOA Cloud
					]
		self.inventoryPath = None
		
		for X in tryPaths:
			if os.path.exists(X):
				self.inventoryPath = X
				break
		
		if self.inventoryPath == None:
			raise Exception('Could not find oraInventory')
		
		invDom = xml.dom.minidom.parse(self.inventoryPath)
		invObj = xml2obj(self.inventoryPath)
		
		if versiontuple(invObj['VERSION_INFO']['SAVED_WITH']) < versiontuple("12"):
			is12c = False
		else:
			is12c = True
		
		self.homeList = []
		dom_homes = []
		
		for X in invDom.getElementsByTagName("HOME"):
			if is12c:
				drFile = os.path.join(X.getAttribute('LOC'), 'domain-registry.xml')
			else:
				drFile = os.path.join(os.path.dirname(X.getAttribute('LOC')), 'domain-registry.xml')
			if os.path.exists(drFile):
				drDom = xml.dom.minidom.parse(drFile)
				for Y in drDom.getElementsByTagName('domain'):
					if os.path.exists(Y.getAttribute('location')):
						domDict = {
								'IDX': X.getAttribute('IDX'),
								'MW_HOME': X.getAttribute('LOC'),
								'DOMAIN_HOME': Y.getAttribute('location'),
							}
						if not(domDict['DOMAIN_HOME'] in dom_homes):
							dom_homes.append(domDict['DOMAIN_HOME'])
							self.homeList.append(domDict)
		
		if len(self.homeList) == 0:
			raise Exception('Could not find any domain homes')
		
	
