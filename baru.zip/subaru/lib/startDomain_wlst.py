import subaruwlst
from startNodeManager_wlst import startNM
from startServer_wlst import startMS

domCfg = subaruwlst.domainConfig()

startNM(domCfg)

domCfg.bootOrder.sort()
for (None,X) in domCfg.bootOrder:
	if X in domCfg.serversOnHost:
		startMS(X, domCfg)


