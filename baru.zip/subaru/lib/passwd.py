import random
import os
import sys

def mkpasswd(numWords=2, numNumeric=1):
	f = open(os.path.join(os.environ['SUBARU_SCRIPT_HOME'], "etc/dictionary.txt"), 'r')
	lines = f.read().splitlines()
	f.close()
	
	passwd = ''
	for X in range(numWords):
		passwd = passwd + random.choice(lines).title()
	
	for X in range(numNumeric):
		passwd = passwd + str(random.randint(0,9))
	
	return passwd
	

