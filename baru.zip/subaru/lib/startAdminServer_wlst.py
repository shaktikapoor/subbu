import subaruwlst

domCfg = subaruwlst.domainConfig()
domCfg.debug()

if domCfg.adminServer in domCfg.serversOnHost:
    nmConnect(domCfg.nmUser, domCfg.nmPass(), domCfg.nmHost, domCfg.nmPort, domCfg.domainName, domCfg.domainHome, domCfg.nmType)
    nmStart(domCfg.adminServer)
else:
    raise Exception("AdminServer does not run on this server")

