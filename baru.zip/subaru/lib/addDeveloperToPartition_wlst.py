import subaruwlst
import wl
import sys

def addDeveloperToPartition(V_USER_NAME, V_PARTITION_NAME, domCfg=None):
	if domCfg == None:
		domCfg = subaruwlst.domainConfig()
	
	if domCfg.adminServer in domCfg.serversOnHost:
		wl.connect(domCfg.adminUser(), domCfg.adminPass(), 't3://%s:%s' % (domCfg.servers[domCfg.adminServer]['listen_address'],domCfg.servers[domCfg.adminServer]['listen_port']))
		wl.grantAppRole('soa-infra',V_PARTITION_NAME+'_ApplicationOperator','weblogic.security.principal.WLSUserImpl',V_USER_NAME)
		wl.grantAppRole('soa-infra',V_PARTITION_NAME+'_Composer','weblogic.security.principal.WLSUserImpl',V_USER_NAME)
		wl.grantAppRole('soa-infra',V_PARTITION_NAME+'_Deployer','weblogic.security.principal.WLSUserImpl',V_USER_NAME)
		wl.grantAppRole('soa-infra',V_PARTITION_NAME+'_Monitor','weblogic.security.principal.WLSUserImpl',V_USER_NAME)
		wl.grantAppRole('soa-infra',V_PARTITION_NAME+'_Tester','weblogic.security.principal.WLSUserImpl',V_USER_NAME)
	else:
		print "Must be on host that runs the admin server to manage users"
	

if (__name__ == "__main__") or (__name__ == "main"):
	V_USER_NAME=sys.argv[1]
	V_PARTITION_NAME=sys.argv[2]
	
	print("V_USER_NAME = "+V_USER_NAME)
	print("V_PARTITION_NAME = "+V_PARTITION_NAME)
	print("")
	print("")
	
	addDeveloperToPartition(V_USER_NAME, V_PARTITION_NAME)

