import subaruwlst
import java.lang.System
import os

print "Generating wl module..."
writeIniFile(os.path.join(os.path.realpath(os.path.dirname(sys.argv[0])), "wl.py"))
print

print "Parsing domain config..."
domCfg = subaruwlst.domainConfig(ignoreSubaruCfg=True)
print

print "Configuring admin credentials..."
foundCreds = False
for X in domCfg.serversOnHost:
	bootprop = os.path.join(domCfg.domainHome, 'servers', X, 'security', 'boot.properties')
	if os.path.exists(bootprop):
		print "Found boot.properties file--attempting to fetch admin credentials"
		props = subaruwlst.load_properties(bootprop)
		adminUser = subaruwlst.decrypt(domCfg.domainHome, props['username'])
		adminPass = subaruwlst.decrypt(domCfg.domainHome, props['password'])
		foundCreds = True
		break

if not(foundCreds):
	print "Could not find admin credentials--enter them now"
	
	adminUser = raw_input('Username: ')
	adminPass = "".join(java.lang.System.console().readPassword("%s", ['Password: ']))
print

print "Configuring boot order..."
while True:
	domCfg.bootOrder.sort()
	print '    order:server'
	for i,X in enumerate(domCfg.bootOrder):
		print '[%s] %s:%s' % (i, X[0], X[1])
	print '[S] Save and exit'
	selection=raw_input('Choose an item to edit: ')
	
	if selection.isnumeric():
		selection = int(selection)
	else:
		selection = selection.upper()
	
	if selection =='S':
		break
	elif isinstance(selection, int) and selection >= 0 and selection < len(domCfg.bootOrder):
		while True:
			print '[0-9] Set boot position'
			print '  [D] Delete managed server from list'
			print '  [C] Cancel'
			selection2=raw_input('Choose an option: ')

			if selection2.isnumeric():
				selection2 = int(selection2)
			else:
				selection2 = selection2.upper()

			if isinstance(selection2, int):
				domCfg.bootOrder[selection]=(selection2, domCfg.bootOrder[selection][1])
				break
			elif selection2 == 'D':
				selection3=raw_input('Are you sure you want to remove %s? [Y/N]' % (domCfg.bootOrder[selection][1]))
				if selection3.upper() == 'Y':
					domCfg.bootOrder.remove(selection)
					break
			else:
				print "Invalid selection"
	else:
		print "Unknown Option Selected!"
print

print "Generating subaru.xml..."
subaruCfg = open(domCfg.subaruCfgFile, 'w')
subaruCfg.write('<subaruwlst>\n')
subaruCfg.write('	<adminUser>%s</adminUser>\n' % (subaruwlst.encrypt(domCfg.domainHome, adminUser)))
subaruCfg.write('	<adminPass>%s</adminPass>\n' % (subaruwlst.encrypt(domCfg.domainHome, adminPass)))
for X in domCfg.bootOrder:
	subaruCfg.write('	<bootOrder idx="%s" server="%s"/>\n' % (X[0], X[1]))
subaruCfg.write('</subaruwlst>\n')
subaruCfg.close()
print
