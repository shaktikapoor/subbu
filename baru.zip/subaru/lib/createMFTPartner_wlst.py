import subaruwlst
import wl
import sys
import os
from createFTPDirectory_wlst import createFTPDirectory
from passwd import mkpasswd

def createMFTPartner(mftenv, mftuser, domCfg=None):
	if mftenv not in ('DEV','QA','PROD'):
		raise Exception("Environment must be one of: DEV, QA, PROD")
	
	origmftuser = mftuser
	if mftenv != 'PROD':
		mftuser = mftuser+'_'+mftenv
	
	if domCfg == None:
		domCfg = subaruwlst.domainConfig()
	
	mftserver = ''
	for X in domCfg.servers.keys():
		if X != domCfg.adminServer:
			mftserver = X
	if X == '':
		raise Exception("Could not identify managed server for MFT")
	else:
		
		wl.connect(domCfg.adminUser(), domCfg.adminPass(), 't3://%s:%s' % (domCfg.servers[domCfg.adminServer]['listen_address'],domCfg.servers[domCfg.adminServer]['listen_port']))
		
		wl.serverConfig()
		
		sr = wl.cmo.getSecurityConfiguration().getDefaultRealm()
		rm = sr.lookupRoleMapper('XACMLRoleMapper')
		atnr=sr.lookupAuthenticationProvider('DefaultAuthenticator')
		
		passwd = mkpasswd()
		atnr.createUser(mftuser, passwd, "MFT FTP Partner")
		
		wl.disconnect()
		
		createFTPDirectory(mftenv, origmftuser, "To", domCfg)
		createFTPDirectory(mftenv, origmftuser, "From", domCfg)
		
		
		

if (__name__ == "__main__") or (__name__ == "main"):
	raise Exception("command line invocation not implemented")




