import subaruwlst
import pprint

domCfg = subaruwlst.domainConfig()
pprint.pprint(domCfg.servers)
