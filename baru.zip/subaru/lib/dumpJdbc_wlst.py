import subaruwlst
import os

domCfg = subaruwlst.domainConfig()

print 'Initializing security module, be patient...'
subaruwlst.decrypt(domCfg.domainHome, '')
print

jdbcPath = os.path.join(domCfg.domainHome, 'config', 'jdbc')

for X in os.listdir(jdbcPath):
    filen = os.path.join(jdbcPath, X)
    if os.path.isfile(filen) and X.endswith('.xml'):
        xmlObj = subaruwlst.xml2obj(filen)
        print 'DataSource:	%s' % (xmlObj.name)
        print 'URL:	%s' % (xmlObj.jdbc_driver_params.url)
        for Y in xmlObj.jdbc_driver_params.properties.property:
            if Y.name == 'user':
                print 'Username:	%s' % (Y.value)
        print 'Password:	%s' % (subaruwlst.decrypt(domCfg.domainHome, xmlObj.jdbc_driver_params.password_encrypted))
        print
        print
        

