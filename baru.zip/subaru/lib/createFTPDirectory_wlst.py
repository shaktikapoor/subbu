import subaruwlst
import wl
import sys
import os

def createFTPDirectory(mftenv, mftuser, directory, domCfg=None):
	if mftenv not in ('DEV','QA','PROD'):
		raise Exception("Environment must be one of: DEV, QA, PROD")
	
	if mftenv != 'PROD':
		mftuser = mftuser+'_'+mftenv
	
	if domCfg == None:
		domCfg = subaruwlst.domainConfig()
	
	mftserver = ''
	for X in domCfg.servers.keys():
		if X != domCfg.adminServer:
			mftserver = X
	if X == '':
		raise Exception("Could not identify managed server for MFT")
	else:
		wl.connect(domCfg.adminUser(), domCfg.adminPass(), 't3://%s:%s' % (domCfg.servers[mftserver]['listen_address'],domCfg.servers[mftserver]['listen_port']))
		
		mftpath = "%s/%s/%s" % (mftenv, mftuser, directory)
		
		os.mkdir(os.path.join(domCfg.domainHome,'mft','ftp_root',mftpath), mode=0750)
		grantPermissionToDirectory('/'+mftpath,mftuser,"USER","LIST","SFTP",false)
		
		print "Granted %s LIST access to %s" % (mftuser, mftpath)
		
		wl.disconnect()
		

if (__name__ == "__main__") or (__name__ == "main"):
	raise Exception("command line invocation not implemented")




