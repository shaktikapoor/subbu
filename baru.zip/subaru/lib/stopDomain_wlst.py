import subaruwlst
from stopNodeManager_wlst import stopNM
from stopServer_wlst import stopMS

domCfg = subaruwlst.domainConfig()

# Preload security modules
domCfg.adminUser()

domCfg.bootOrder.reverse()
for (None,msName) in domCfg.bootOrder:
	if X in domCfg.serversOnHost:
		stopMS(msName, domCfg)

stopNM(domCfg)

