import subaruwlst
import time
import os
import wl

def stopNM(domCfg=None):
	if domCfg == None:
		domCfg = subaruwlst.domainConfig()
	if subaruwlst.check_server(domCfg.nmHost, domCfg.nmPort):
		wl.nmConnect(domCfg.nmUser, domCfg.nmPass(), domCfg.nmHost, domCfg.nmPort, domCfg.domainName, domCfg.domainHome, domCfg.nmType)
		wl.stopNodeManager()
		ret=1
		for X in range(30):
			if subaruwlst.check_server(domCfg.nmHost, domCfg.nmPort):
				time.sleep(1)
			else:
				ret=0
				break
		
		if ret:
			print "Could not connect to nodemanager within timeout period.  Did it work?"
		
		return ret

	else:
		print "NodeManager already stopped"
		return 0

if (__name__ == "__main__") or (__name__ == "main"):
	ret=stopNM()
	sys.exit(ret)

