#! /usr/bin/env python

import os
import imp
import subprocess
import pprint
import sys

tmpfn = sys.argv[1]
tmpf = open(tmpfn, 'a')

domainName = None
if len(sys.argv) == 3:
	domainName = sys.argv[2]

modpath = os.path.normpath(os.path.join(os.path.dirname(os.path.realpath(__file__)), '../lib/subaruwlst.py'))
imp.load_source('subaruwlst', modpath)
import subaruwlst

oraInv = subaruwlst.oraInventory()

if not(domainName):
	selection = ''

	if len(oraInv.homeList) == 1:
		selection=0
		print "Only one domain home, using that: "+oraInv.homeList[0]['DOMAIN_HOME']
	else:
		while True:
			for idx in range(len(oraInv.homeList)):
				print '[%s] %s' % (idx, oraInv.homeList[idx]['DOMAIN_HOME'])
			
			selection = int(raw_input('Choose: '))
			if (int(selection) >= 0) and (int(selection) < len(oraInv.homeList)):
				break
	
	scriptPath = os.path.join(oraInv.homeList[selection]['DOMAIN_HOME'],'bin','setDomainEnv.sh')

	tmpf.write("source %s\n" % (scriptPath))
else:
	found = False
	for idx in range(len(oraInv.homeList)):
		if os.path.basename(oraInv.homeList[idx]['DOMAIN_HOME']) == domainName:
			scriptPath = os.path.join(oraInv.homeList[idx]['DOMAIN_HOME'],'bin','setDomainEnv.sh')
			tmpf.write("source %s\n" % (scriptPath))
			found = True
			break
	if not(found):
		print "Could not find domain %s" % (domainName)

tmpf.close()
