import subaruwlst
from passwd import mkpasswd

def wlsPasswd(user, passwd=None, domCfg=None):
	if domCfg == None:
		domCfg = subaruwlst.domainConfig()
	if passwd == None:
		passwd = mkpasswd()
	
	connect(domCfg.adminUser(), domCfg.adminPass(), 't3://%s:%s' % (domCfg.servers[domCfg.adminServer]['listen_address'],domCfg.servers[domCfg.adminServer]['listen_port']))
	
	cd('SecurityConfiguration/'+domCfg.domainName+'/DefaultRealm/myrealm/AuthenticationProviders/DefaultAuthenticator')
	
	cmo.resetUserPassword(user, passwd)
	print "%s	%s" % (user, passwd)


if (__name__ == "__main__") or (__name__ == "main"):
	if len(sys.argv) == 3
		wlsPasswd(str(sys.argv[1]), str(sys.argv[2))
	elif len(sys.argv) == 2
		wlsPasswd(str(sys.argv[1]))
	else:
		print "Usage: wlsPasswd Username [Password]"
