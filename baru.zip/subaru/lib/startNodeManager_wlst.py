import subaruwlst
import time
import os
import wl

def startNM(domCfg=None):
	if domCfg == None:
		domCfg = subaruwlst.domainConfig()
	
	if subaruwlst.check_server(domCfg.nmHost, domCfg.nmPort):
		print "NodeManager already started"
		return 0
	else:
		if subaruwlst.versiontuple(domCfg.domainVersion) < subaruwlst.versiontuple("12"):
			os.system('${WL_HOME}/server/bin/startNodeManager.sh </dev/null >'+domCfg.domainHome+'/nodemanager.console_log 2>&1 &')
		else:
			os.system('/bin/env -i /bin/sh -l -c '+domCfg.domainHome+'/bin/startNodeManager.sh </dev/null >'+domCfg.domainHome+'/nodemanager.console_log 2>&1 &')
			#wl.startNodeManager()
		ret=1
		for X in range(30):
			if subaruwlst.check_server(domCfg.nmHost, domCfg.nmPort):
				ret=0
				break
			else:
				time.sleep(1)
		
		if ret:
			print "Could not connect to nodemanager within timeout period.  Did it work?"
		
		return ret

if (__name__ == "__main__") or (__name__ == "main"):
	ret=startNM()
	sys.exit(ret)

