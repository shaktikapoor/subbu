import subaruwlst
import sys
import wl

def stopMS(msName, domCfg=None):
	if domCfg == None:
		domCfg = subaruwlst.domainConfig()
	
	if msName in domCfg.serversOnHost:
		if subaruwlst.check_server(domCfg.servers[msName]['listen_address'],domCfg.servers[msName]['listen_port']):
			try:
				wl.connect(domCfg.adminUser(), domCfg.adminPass(), 't3://%s:%s' % (domCfg.servers[msName]['listen_address'],domCfg.servers[msName]['listen_port']))
				wl.shutdown(name=msName, entityType='Server',  ignoreSessions='true', force='false', timeOut=600, block='true')
			except:
				pass
		if subaruwlst.check_server(domCfg.servers[msName]['listen_address'],domCfg.servers[msName]['listen_port']):
			try:
				wl.nmConnect(domCfg.nmUser, domCfg.nmPass(), domCfg.nmHost, domCfg.nmPort, domCfg.domainName, domCfg.domainHome, domCfg.nmType)
				wl.nmKill(msName)
			except:
				pass
		
	else:
		raise Exception("'%s' does not run on this server" % (msName))
	

if (__name__ == "__main__") or (__name__ == "main"):
	stopMS(str(sys.argv[1]))
