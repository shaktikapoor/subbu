import subaruwlst
import sys
import wl

def startMS(msName, domCfg=None):
	if domCfg == None:
		domCfg = subaruwlst.domainConfig()
	if msName in domCfg.serversOnHost:
		try:
			wl.nmConnect(domCfg.nmUser, domCfg.nmPass(), domCfg.nmHost, domCfg.nmPort, domCfg.domainName, domCfg.domainHome, domCfg.nmType)
			wl.nmStart(msName)
			wl.nmDisconnect()
		except:
			pass
	else:
		raise Exception("'%s' does not run on this server" % (msName))

if (__name__ == "__main__") or (__name__ == "main"):
	startMS(str(sys.argv[1]))
