This folder should be used to store host-specific files/scripts which will not be overwritten when
the scripts are updated.  This folder should remain empty in SVN.